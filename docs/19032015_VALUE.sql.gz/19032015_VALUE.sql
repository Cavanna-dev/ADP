-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Jeu 19 Mars 2015 à 11:22
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `ttls`
--

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idCategory` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `idDescription` int(11) DEFAULT NULL,
  `reference` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `isActive` int(1) DEFAULT '2',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`,`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `article`
--

INSERT INTO `article` (`id`, `idCategory`, `idUser`, `idDescription`, `reference`, `name`, `brand`, `picture`, `isActive`, `dateCreate`, `dateChange`) VALUES
(1, 7, 1, 1, 'A3-3P', 'A3', 'Audi', 'audi.jpg', 1, '2015-03-19 10:19:01', '2015-03-19 10:26:49'),
(2, 5, 1, NULL, 'AIA2-2015', 'IPad Air 2', 'Apple', 'iPad.jpeg', 2, '2015-03-19 10:24:41', '2015-03-19 10:24:41'),
(3, 10, 1, NULL, 'RPID4-G', 'GEOX White &amp; Grey', 'GEOX', 'jordan.jpg', 1, '2015-03-19 10:38:25', '2015-03-19 10:38:50');

-- --------------------------------------------------------

--
-- Structure de la table `availability`
--

CREATE TABLE IF NOT EXISTS `availability` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idArticle` int(11) NOT NULL,
  `idUserSales` int(11) NOT NULL,
  `idOrder` int(11) DEFAULT NULL,
  `price` decimal(18,2) NOT NULL,
  `currency` varchar(20) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `carousel`
--

CREATE TABLE IF NOT EXISTS `carousel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `isHp` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idParent` int(11) NOT NULL,
  `idAdminUser` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `name_2` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `category`
--

INSERT INTO `category` (`id`, `idParent`, `idAdminUser`, `name`, `isActive`, `dateCreate`, `dateChange`) VALUES
(1, 0, 1, 'Voiture', 1, '2015-03-19 10:15:54', '2015-03-19 10:15:54'),
(2, 0, 1, 'MultimÃ©dia', 1, '2015-03-19 10:15:58', '2015-03-19 10:15:58'),
(3, 0, 1, 'Sport', 1, '2015-03-19 10:16:08', '2015-03-19 10:16:08'),
(4, 0, 1, 'SantÃ©', 1, '2015-03-19 10:16:13', '2015-03-19 10:16:13'),
(5, 2, 1, 'Tablette', 1, '2015-03-19 10:16:21', '2015-03-19 10:16:21'),
(6, 2, 1, 'Ordinateur Portable', 1, '2015-03-19 10:16:29', '2015-03-19 10:16:29'),
(7, 1, 1, 'Compact', 1, '2015-03-19 10:17:12', '2015-03-19 10:17:12'),
(9, 1, 1, 'Berline', 1, '2015-03-19 10:17:40', '2015-03-19 10:17:40'),
(10, 3, 1, 'Chaussures', 1, '2015-03-19 10:32:26', '2015-03-19 10:32:26');

-- --------------------------------------------------------

--
-- Structure de la table `command`
--

CREATE TABLE IF NOT EXISTS `command` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idUserBuy` int(11) NOT NULL,
  `nbProduct` int(11) NOT NULL,
  `price` decimal(18,2) NOT NULL,
  `currency` varchar(10) NOT NULL DEFAULT '€',
  `status` int(11) NOT NULL DEFAULT '0',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) NOT NULL,
  `idAdminUser` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `subject` varchar(100) NOT NULL,
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `town` varchar(100) DEFAULT NULL,
  `post` varchar(15) DEFAULT NULL,
  `dateBirth` date DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `customer`
--

INSERT INTO `customer` (`id`, `email`, `password`, `name`, `firstName`, `address`, `town`, `post`, `dateBirth`, `isActive`, `dateCreate`, `dateChange`) VALUES
(1, 'leger.au@gmail.com', '19dfb08731aaf0bfd190661239db33cf', 'LEGER', 'AurÃ©lien', '2 rue Claude Tillier', 'CANNES', '06100', '2015-03-01', 1, '2015-03-19 10:13:48', '2015-03-19 10:13:48');

-- --------------------------------------------------------

--
-- Structure de la table `description`
--

CREATE TABLE IF NOT EXISTS `description` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) NOT NULL,
  `idArticle` int(11) NOT NULL,
  `idAdminUser` int(11) DEFAULT NULL,
  `valueA` varchar(255) NOT NULL,
  `valueB` varchar(255) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `description`
--

INSERT INTO `description` (`id`, `idUser`, `idArticle`, `idAdminUser`, `valueA`, `valueB`, `isActive`, `dateCreate`, `dateChange`) VALUES
(1, 1, 1, NULL, 'Audi A3 - 3 Portes\r\nDiesel 1.9 TDI - 105 CV\r\nPack : AMBITION\r\nChassi : S-Line', '', 1, '2015-03-19 10:19:52', '2015-03-19 10:19:52'),
(2, 1, 2, NULL, 'Apple iPad Air 2 avec Ã©cran Retina 9,7&#039;&#039; IPS - Processeur Apple A7 64 bits - Stockage 16 Go - RÃ©solution 2 048 x 1 536 pixels - Wi-Fi - Bluetooth 4.0 - Appareil photo iSight 8 Mpx - Enregistrement vidÃ©o HD 1080p (30i/s) - CamÃ©ra FaceTime HD ', '1,2Mpx - Connecteur Lightning - Touch ID - Jusquâ€™Ã  10h d&#039;autonomie - iOS 8', 1, '2015-03-19 10:25:25', '2015-03-19 10:25:25'),
(3, 1, 2, NULL, 'Ceci est une tablette. Elle est belle, lÃ©gÃ¨re et avance bien.\r\nC&#039;est du APPLE.', '', 1, '2015-03-19 10:26:27', '2015-03-19 10:26:27');

-- --------------------------------------------------------

--
-- Structure de la table `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) DEFAULT NULL,
  `value` varchar(40) DEFAULT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `tag_article`
--

CREATE TABLE IF NOT EXISTS `tag_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idTag` int(11) NOT NULL,
  `idArticle` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `dateCreate` datetime DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `role` tinyint(4) DEFAULT '0',
  `isActive` tinyint(4) DEFAULT '1',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `name`, `firstName`, `role`, `isActive`, `dateCreate`, `dateChange`) VALUES
(1, 'SuperAdmin', 'make', 'Administrateur', 'Super', 1, 1, '2015-03-19 10:15:10', '2015-03-19 10:52:42'),
(2, 'leger.au@gmail.com', 'OKLM', 'LEGER', 'AurÃ©lien', 0, 1, '2015-03-19 11:11:02', '2015-03-19 11:11:02');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
