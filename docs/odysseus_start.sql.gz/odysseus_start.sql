-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Jeu 09 Avril 2015 à 14:10
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `ttls`
--

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idCategory` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `idDescription` int(11) DEFAULT NULL,
  `reference` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `isActive` int(1) DEFAULT '2',
  `dateCreate` datetime DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `availability`
--

CREATE TABLE IF NOT EXISTS `availability` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idArticle` int(11) NOT NULL,
  `idUserSales` int(11) NOT NULL,
  `idCommand` int(11) DEFAULT NULL,
  `price` decimal(18,2) NOT NULL,
  `currency` varchar(20) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `carousel`
--

CREATE TABLE IF NOT EXISTS `carousel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `isHp` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idParent` int(11) NOT NULL,
  `idAdminUser` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `name_2` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `command`
--

CREATE TABLE IF NOT EXISTS `command` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idUserBuy` int(11) NOT NULL,
  `nbProduct` int(11) NOT NULL,
  `price` decimal(18,2) NOT NULL,
  `currency` varchar(10) NOT NULL DEFAULT '€',
  `status` int(11) NOT NULL DEFAULT '0',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) CHARACTER SET utf8 NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Contenu de la table `config`
--

INSERT INTO `config` (`id`, `label`, `value`, `isActive`, `dateCreate`, `dateChange`) VALUES
(1, 'nameBo', 'Back Office', 1, '2015-03-31 11:15:39', '2015-04-03 23:20:33'),
(2, 'nameFo', 'Odysseus', 1, '2015-03-31 11:16:25', '2015-04-03 23:21:02'),
(3, 'emailContact', 'contact@odysseus.fr', 1, '2015-03-31 11:16:43', '2015-04-09 10:57:14'),
(4, 'titleBo', 'Back Office ', 1, '2015-04-03 12:06:53', '2015-04-08 11:15:49'),
(5, 'titleFo', 'Odysseus', 1, '2015-04-03 12:09:07', '2015-04-03 23:20:59'),
(6, 'imgFavFo', 'unnamed.png', 1, '2015-04-03 12:27:31', '2015-04-09 10:58:59'),
(7, 'imgFavBo', 'unnamed.png', 1, '2015-04-03 12:27:41', '2015-04-09 10:59:05'),
(8, 'imgFo', 'unnamed.png', 1, '2015-04-03 12:29:56', '2015-04-09 10:58:17'),
(9, 'imgBo', '', 1, '2015-04-03 12:30:17', '2015-04-08 21:44:28'),
(10, 'emailSend', 'no-reply@odysseus.fr', 1, '2015-04-03 22:53:52', '2015-04-09 10:57:19');

-- --------------------------------------------------------

--
-- Structure de la table `config_css`
--

CREATE TABLE IF NOT EXISTS `config_css` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(40) NOT NULL,
  `value` varchar(40) NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT '0',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- Contenu de la table `config_css`
--

INSERT INTO `config_css` (`id`, `label`, `value`, `isActive`, `dateCreate`, `dateChange`) VALUES
(1, 'templateFo', 'Superhero', 0, '2015-04-03 20:42:18', '2015-04-08 19:39:06'),
(2, 'templateFo', 'Slate', 0, '2015-04-03 20:48:10', '2015-04-03 23:56:32'),
(3, 'templateFo', 'Cerulean', 1, '2015-04-03 21:09:44', '2015-04-09 11:02:13'),
(4, 'templateFo', 'Cosmo', 0, '2015-04-03 21:13:54', '2015-04-03 21:14:03'),
(5, 'templateFo', 'Cyborg', 0, '2015-04-03 21:17:20', '2015-04-03 21:17:29'),
(6, 'templateFo', 'Darkly', 0, '2015-04-03 21:21:53', '2015-04-08 10:39:57'),
(7, 'templateFo', 'Flatly', 0, '2015-04-03 21:28:56', '2015-04-05 01:06:05'),
(8, 'templateFo', 'Journal', 0, '2015-04-03 21:37:33', '2015-04-08 10:53:34'),
(9, 'templateFo', 'Lumen', 0, '2015-04-03 21:42:35', '2015-04-03 21:42:42'),
(10, 'templateFo', 'Paper', 0, '2015-04-03 21:45:22', '2015-04-03 21:46:17'),
(11, 'templateFo', 'Readable', 0, '2015-04-03 21:50:34', '2015-04-03 21:53:28'),
(12, 'templateFo', 'Sandstone', 0, '2015-04-03 21:54:29', '2015-04-03 23:19:59'),
(13, 'templateFo', 'Simplex', 0, '2015-04-03 21:58:29', '2015-04-03 22:02:01'),
(14, 'templateFo', 'Spacelab', 0, '2015-04-03 22:02:20', '2015-04-03 22:04:22'),
(15, 'templateFo', 'United', 0, '2015-04-03 22:04:13', '2015-04-03 23:02:07'),
(16, 'templateFo', 'Yeti', 0, '2015-04-03 22:06:09', '2015-04-03 23:19:42'),
(17, 'templateBo', 'Superhero', 1, '2015-04-03 22:41:58', '2015-04-08 19:39:12'),
(18, 'templateBo', 'Slate', 0, '2015-04-03 22:41:58', '2015-04-04 11:55:27'),
(19, 'templateBo', 'Cerulean', 0, '2015-04-03 22:42:30', '2015-04-04 23:43:32'),
(20, 'templateBo', 'Cosmo', 0, '2015-04-03 22:42:30', '2015-04-03 22:42:30'),
(21, 'templateBo', 'Cyborg', 0, '2015-04-03 22:42:54', '2015-04-03 22:42:54'),
(22, 'templateBo', 'Darkly', 0, '2015-04-03 22:42:54', '2015-04-03 23:57:05'),
(23, 'templateBo', 'Flatly', 0, '2015-04-03 22:43:20', '2015-04-03 22:43:20'),
(24, 'templateBo', 'Journal', 0, '2015-04-03 22:43:20', '2015-04-03 23:08:38'),
(25, 'templateBo', 'Lumen', 0, '2015-04-03 22:43:41', '2015-04-03 22:43:41'),
(26, 'templateBo', 'Paper', 0, '2015-04-03 22:43:41', '2015-04-04 12:06:32'),
(27, 'templateBo', 'Readable', 0, '2015-04-03 22:43:58', '2015-04-07 09:32:58'),
(28, 'templateBo', 'Sandstone', 0, '2015-04-03 22:43:58', '2015-04-04 12:05:39'),
(29, 'templateBo', 'Simplex', 0, '2015-04-03 22:44:26', '2015-04-08 19:39:00'),
(30, 'templateBo', 'Spacelab', 0, '2015-04-03 22:44:26', '2015-04-04 11:55:24'),
(31, 'templateBo', 'United', 0, '2015-04-03 22:44:49', '2015-04-04 11:55:16'),
(32, 'templateBo', 'Yeti', 0, '2015-04-03 22:44:49', '2015-04-04 11:55:18');

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) DEFAULT NULL,
  `name` varchar(60) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `idAdminUser` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `subject` varchar(100) NOT NULL,
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `town` varchar(100) DEFAULT NULL,
  `post` varchar(15) DEFAULT NULL,
  `dateBirth` date DEFAULT NULL,
  `passChange` int(11) NOT NULL DEFAULT '0',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `description`
--

CREATE TABLE IF NOT EXISTS `description` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) NOT NULL,
  `idArticle` int(11) NOT NULL,
  `idAdminUser` int(11) DEFAULT NULL,
  `valueA` varchar(255) NOT NULL,
  `valueB` varchar(255) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `role` tinyint(4) DEFAULT '0',
  `isActive` tinyint(4) DEFAULT '1',
  `dateCreate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateChange` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `name`, `firstName`, `role`, `isActive`, `dateCreate`, `dateChange`) VALUES
(1, 'SuperAdmin', 'b73e3b2d42e833eb44837c4c309b3678', 'Admin', 'Super', 1, 1, '2015-04-03 11:37:25', '2015-04-09 11:12:20');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
